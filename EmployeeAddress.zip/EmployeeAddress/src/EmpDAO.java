import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.sql.DataSource;

public class EmpDAO {
	private DataSource dataSource;
	Scanner sc=new Scanner(System.in);
	public Connection con;
    public Statement st;
    public ResultSet rs;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public void updateAddress() throws SQLException
	{
		System.out.println("Enter the employee ID which you want to update: ");
		int empNo=sc.nextInt();
		AddressDetails ob=new AddressDetails();
		con =dataSource.getConnection();
		st = con.createStatement();
        rs = st.executeQuery("select * from ITEM");
        while(rs.next())
        {
        	if(rs.getString(1).equals(empNo))
        	{
        		System.out.println("Enter the new employee State, City and PinCode:");
                String state=sc.next();
                String city=sc.next();
                String pin=sc.next();
                String query="update address set state='"+state+"',city='"+city+"',pincode='"+pin+"' where empid='"+empNo+"' ";  
                st.executeUpdate(query);
                System.out.println("Employee address updated successfully with id="+empNo);
        	}
        	else
        		System.out.println("No Employee found with id="+empNo);  
        }
     }
	
	
	public void updateCommission(int empNo,double commission) throws SQLException
	{
		con =dataSource.getConnection();
		st = con.createStatement();
        rs = st.executeQuery("select * from employee");
        while(rs.next())
        {
        	if(rs.getString(1).equals(empNo))
        	{
        		String query="update employee set empComm='"+commission+"' where empid='"+empNo+"' ";  
                st.executeUpdate(query);
                System.out.println("Employee commission updated successfully with id="+empNo);
        	}
        	else
        		System.out.println("No Employee found with id="+empNo);  
        }
	}
	
	
	public void updateEmpName(int empNo,String eName) throws SQLException
	{
		con =dataSource.getConnection();
		st = con.createStatement();
        rs = st.executeQuery("select * from employee");
        while(rs.next())
        {
        	if(rs.getString(1).equals(empNo))
        	{
        		String query="update employee set empName='"+eName+"' where empid='"+empNo+"' ";  
                st.executeUpdate(query);
                System.out.println("Employee name updated successfully with id="+empNo);
        	}
        	else
        		System.out.println("No Employee found with id="+empNo);  
        }
	}
	
	
	public void updateEmpPhone(int empNo,String ePhone) throws SQLException
	{
		con =dataSource.getConnection();
		st = con.createStatement();
        rs = st.executeQuery("select * from employee");
        while(rs.next())
        {
        	if(rs.getString(1).equals(empNo))
        	{
        		String query="update employee set empPhone='"+ePhone+"' where empid='"+empNo+"' ";  
                st.executeUpdate(query);
                System.out.println("Employee phone number updated successfully with id="+empNo);
        	}
        	else
        		System.out.println("No Employee found with id="+empNo);  
        }
	}
	

}
