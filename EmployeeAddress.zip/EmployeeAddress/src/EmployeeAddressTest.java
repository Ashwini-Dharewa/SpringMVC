import java.sql.SQLException;
import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;


public class EmployeeAddressTest {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		ApplicationContext ctx=new ClassPathXmlApplicationContext("context.xml");

        EmpDAO employee=(EmpDAO)ctx.getBean("employeeObj");
        System.out.println("Select the operation which you want to perform: ");
        System.out.println("1.Get all Employees.\n2.Get Employee by Employee ID.\n3.Get the highest Salary."
        		+ "\n4.Update Commission.\n5.Add new Employee.\n6.Remove Employee by Employee ID."
        		+ "\n7.Update Employee Name.\n8.Update Employee Phone Number.\n9.Update Employee Address.");
        System.out.println("Enter your choice:");
        int n=sc.nextInt();
        EmpDAO ob=new EmpDAO();
        switch(n)
        {
       /*// case 1:ob.getEmployees();
        //case 2:ob.getEmployeeById();
        //case 3:ob.getEmployees();*/
        case 4:System.out.println("Enter the employee ID and the new commission value: ");
        	   int eId=sc.nextInt();
        	   double comm=sc.nextDouble();
        	   ob.updateCommission(eId,comm);
        	   break;
        	   
       /* case 5:ob.getEmployees();
               break;
        case 6:ob.getEmployees();
               break;*/
        case 7:System.out.println("Enter the employee ID and the new Employee name : ");
 	   			int eId2=sc.nextInt();
 	   			String name=sc.next();
 	   			ob.updateEmpName(eId2,name);
 	   			break;
        case 8:System.out.println("Enter the employee ID and the new Employee phone number : ");
			   int eId1=sc.nextInt();
			   String phNo=sc.next();
			   ob.updateEmpPhone(eId1,phNo);
			   break;
        case 9:ob.updateAddress();
               break;
        default:System.out.println("You have entered a wrong choice!!");
        }


	}

}
