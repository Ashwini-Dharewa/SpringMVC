package LambdaExpressions;

public interface CheckOdd {
	public boolean isOdd(int n);

}
