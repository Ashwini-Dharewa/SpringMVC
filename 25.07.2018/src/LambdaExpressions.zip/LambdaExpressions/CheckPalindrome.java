package LambdaExpressions;

public interface CheckPalindrome {
	public boolean isPalindrome(int n);

}
