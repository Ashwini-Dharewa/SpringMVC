package LambdaExpressions;

public interface CheckPrime {
	public boolean isPrime(int n);

}
