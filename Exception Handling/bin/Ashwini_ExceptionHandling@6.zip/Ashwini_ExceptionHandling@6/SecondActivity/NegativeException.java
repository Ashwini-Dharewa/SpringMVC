package SecondActivity;

public class NegativeException extends Exception{
	public NegativeException()
	{
		System.out.println("java.lang.Exception: n or p should not be negative");
	}

}
