package SecondActivity;

public class SingleZeroException extends Exception{
	public SingleZeroException()
	{
		System.out.println("java.lang.Exception: n or p should not be zero");
	}

}
