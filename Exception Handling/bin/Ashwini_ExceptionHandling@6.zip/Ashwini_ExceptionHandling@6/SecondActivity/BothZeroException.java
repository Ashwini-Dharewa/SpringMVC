package SecondActivity;

public class BothZeroException extends Exception{
	public BothZeroException()
	{
		System.out.println("java.lang.Exception: n and p should not be zero");
	}

}
