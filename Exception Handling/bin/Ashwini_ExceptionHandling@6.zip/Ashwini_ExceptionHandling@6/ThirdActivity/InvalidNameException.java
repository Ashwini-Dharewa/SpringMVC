package ThirdActivity;

public class InvalidNameException extends Exception{
	public InvalidNameException()
	{
		System.out.println("Name is not valid");
	}

}
