package ThirdActivity;

public class InvalidAgeException extends Exception{
	public InvalidAgeException()
	{
		System.out.println("Age is not valid");
	}

}
