package SixthActivity;

public class StringTooLongException extends Exception{
	public StringTooLongException()
	{
		System.out.println("String entered is too long!!");
	}

}
