package SeventhActivity;

public class InvalidInputException extends Exception{
	public InvalidInputException()
	{
		System.out.println("Please enter floating point numbers only!!");
	}

}
