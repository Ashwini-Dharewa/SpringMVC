package FifthActivity;

public class InvalidInputException extends Exception{
	public InvalidInputException()
	{
		System.out.println("Invalid Input!!");
	}

}
