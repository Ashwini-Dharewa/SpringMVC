package FifthActivity;

public class FactorialException extends Exception{
	public FactorialException()
	{
		System.out.println("Output exceeds limit!!");
	}

}
