package FourthActivity;

public class InvalidMonthException extends Exception{
	public InvalidMonthException()
	{
		System.out.println("Month is invalid.");
	}

}
