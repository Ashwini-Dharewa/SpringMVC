package FourthActivity;
import java.util.*;
public class MyDate {
	int d,m,y;
	public MyDate(int dd,int mm,int yy)
	{
		d=dd;
		m=mm;
		y=yy;
	}
	public void check()
	{
		try
		{
			if(m==1 || m==3 || m==5 || m==7 || m==8 || m==10 ||m==12)
			{
			if(d<1 || d>31)
				throw new InvalidDayException();
			}
			else
			{
				if(d<1 || d>30)
					throw new InvalidDayException();
			}
			if(m<1 || m>12)
				throw new InvalidMonthException();
			System.out.println("Valid date");
		}
		catch(InvalidDayException e1)
		{
			e1.getMessage();
		}
		catch(InvalidMonthException e2)
		{
			e2.getMessage();
		}
	}

	public static void main(String[] args) {
		int dd,mm,yy;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter day: ");
		dd=sc.nextInt();
		System.out.println("Enter month: ");
		mm=sc.nextInt();
		System.out.println("Enter year: ");
		yy=sc.nextInt();
		MyDate ob=new MyDate(dd,mm,yy);
		ob.check();

	}

}
