package FourthActivity;

public class InvalidDayException extends Exception{
	public InvalidDayException()
	{
		System.out.println("Day is invalid.");
	}

}
