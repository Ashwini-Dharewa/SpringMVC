package EigthActivity;

public class InvalidInputException extends Exception{
	public InvalidInputException()
	{
		System.out.println("The input given is not valid!");
	}

}
