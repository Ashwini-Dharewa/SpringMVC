package Assignment7;

public class OrderNotValidException extends Exception{
	public OrderNotValidException()
	{
		System.out.println("Order Id is not valid!!");
	}

}
