package Assignment6;

public class Product {

	int prodId;
	String prodName;
	public Product(int i,String n)
	{
		prodId=i;
		prodName=n;
	}
}
