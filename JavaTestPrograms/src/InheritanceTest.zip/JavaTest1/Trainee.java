package JavaTest1;

public class Trainee extends Employee{
	Trainee(long id,String name,String address,long phone,double salary)
	{
		super(id,name,address,phone);
		basicSalary=salary;		
	}


}
